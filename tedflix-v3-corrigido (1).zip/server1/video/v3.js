'use strict';
/** GET /v3/video/* — resolve m3u8/mp4 (fonte v3 + fallback Megaflix) */
const { resolveStream } = require('../lib/stream-resolve');

const API = 3;

function rawFromReq(req) {
  let raw =
    (req.params && (req.params[0] || req.params.url)) ||
    (req.query && (req.query.url || req.query.u)) ||
    '';
  if (!raw && req.originalUrl) {
    const m = String(req.originalUrl).match(/\/v3\/video\/(.+?)(?:\?|$)/i);
    if (m) raw = m[1];
  }
  return String(raw || '').trim();
}

async function handler(req, res) {
  try {
    const raw = rawFromReq(req);
    if (!raw) return res.status(400).json({ success: false, error: 'URL ausente após /v3/video/' });
    const season = req.query?.season || req.query?.s;
    const episode = req.query?.episode || req.query?.e || req.query?.series;
    const title = req.query?.title || req.query?.t || '';
    const stream = await resolveStream({ api: API, raw, title, season, episode });
    if (!stream || !stream.url) {
      return res.status(404).json({ success: false, error: 'Stream não resolvido em m3u8/mp4' });
    }
    return res.json({
      success: true,
      api: API,
      source: stream.source || null,
      format: stream.format,
      url: stream.url,
      headers: stream.headers || {},
    });
  } catch (err) {
    return res.status(err.status || 500).json({ success: false, error: err.message || 'Falha video v3' });
  }
}

module.exports = { handler, API };
