# TEDFLIX Provider API v3

## Subir

```bash
npm install
npm start
```

## Rotas principais

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/health` | Health check |
| GET | `/busca?q=` | Pesquisa (MegaCine + Megaflix) |
| GET | `/filmes` | Catálogo filmes |
| GET | `/series` | Catálogo séries |
| GET | `/banner` | MegaCine lançamentos/destaques |
| GET | `/novos` | TopFilmes destaques |
| GET | `/lancamentos` | Seriesflix lançamentos |
| GET | `/categoria/:slug` | Gênero (megacine + topfilmes) |
| GET | `/streaming/:plat/:tipo` | Netflix, Disney, etc. |
| GET | `/v1..v5/play/*` | Ficha + watch |
| GET | `/v1..v5/video/*` | Stream m3u8/mp4/iframe |

Play prefixes: v1 megacine · v2 megaflix · v3 megafilmeshd · v4 topfilmes · v5 seriesflix
